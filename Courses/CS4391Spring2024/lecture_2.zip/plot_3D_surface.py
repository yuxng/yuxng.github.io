import matplotlib.pyplot as plt
import numpy as np
import cv2

from matplotlib import cm
from matplotlib.ticker import LinearLocator

im = cv2.imread('cracker_box.jpg')
height = im.shape[0]
width = im.shape[1]

# Make data.
X = np.arange(0, width)
Y = np.arange(0, height)
X, Y = np.meshgrid(X, Y)
Z = im[:, :, 0]

# Plot the surface.
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)
plt.show()