#!/usr/bin/env python3
"""
HW4 Part 1 — Inspect a Vision Transformer (ViT)

Run:
    python hw4_vit_understanding.py

This script prints:
  1. the main ViT modules
  2. tensor shapes through the ViT pipeline
  3. the final classification head

Students should use the printed outputs to answer conceptual questions.
"""

import torch
from torchvision import models


def main():
    # --------------------------------------------------
    # 1. Load pretrained ViT-B/16
    # --------------------------------------------------
    weights = models.ViT_B_16_Weights.DEFAULT
    model = models.vit_b_16(weights=weights)
    model.eval()

    print("=" * 80)
    print("Vision Transformer: vit_b_16")
    print("=" * 80)
    print()

    # --------------------------------------------------
    # 2. Print the important modules
    # --------------------------------------------------
    print("Patch embedding layer:")
    print(model.conv_proj)
    print()

    print("Transformer encoder:")
    print(model.encoder)
    print()

    print("Classification head:")
    print(model.heads)
    print()

    # --------------------------------------------------
    # 3. Create a fake input image
    # --------------------------------------------------
    x = torch.randn(2, 3, 224, 224)
    print("Input image shape:")
    print(x.shape)
    print()

    # --------------------------------------------------
    # 4. Convert image to patch embeddings
    # --------------------------------------------------
    x_patch = model._process_input(x)
    print("After patch embedding:")
    print(x_patch.shape)
    print("Meaning: (batch_size, num_patches, embedding_dim)")
    print()

    # --------------------------------------------------
    # 5. Add CLS token
    # --------------------------------------------------
    cls_token = model.class_token.expand(x_patch.shape[0], -1, -1)
    x_tokens = torch.cat([cls_token, x_patch], dim=1)

    print("After adding CLS token:")
    print(x_tokens.shape)
    print("Meaning: (batch_size, num_tokens, embedding_dim)")
    print()

    # --------------------------------------------------
    # 6. Pass tokens through transformer encoder
    # --------------------------------------------------
    x_encoded = model.encoder(x_tokens)

    print("After transformer encoder:")
    print(x_encoded.shape)
    print()

    # --------------------------------------------------
    # 7. Extract the CLS token
    # --------------------------------------------------
    x_cls = x_encoded[:, 0]

    print("CLS token after encoder:")
    print(x_cls.shape)
    print("Meaning: (batch_size, embedding_dim)")
    print()

    # --------------------------------------------------
    # 8. Final classification head
    # --------------------------------------------------
    logits = model.heads(x_cls)

    print("Output logits:")
    print(logits.shape)
    print("Meaning: (batch_size, num_classes)")
    print()

    print("=" * 80)
    print("Done.")
    print("=" * 80)


if __name__ == "__main__":
    main()