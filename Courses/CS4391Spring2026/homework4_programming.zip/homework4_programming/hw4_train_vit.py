#!/usr/bin/env python3
"""
HW4 Part 2 — Train a Vision Transformer (ViT) for image classification

Runs training and saves:
  - predictions_val.csv
  - predictions_test.csv
  - training_curves.png
  - best.pt
  - last.pt

Example:
python hw_part3_train_vit.py --split split.json --pretrained --freeze_backbone --epochs 5 --save_best --tag vit_freeze
"""

import argparse
import csv
import json
from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image

import matplotlib.pyplot as plt


# -------------------------
# Dataset
# -------------------------

class SplitDataset(Dataset):
    def __init__(self, root: Path, items, transform=None):
        self.root = root
        self.items = items  # list of {"path": "...", "y": int}
        self.transform = transform

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        r = self.items[idx]
        img_path = self.root / r["path"]
        y = int(r["y"])

        with Image.open(img_path) as im:
            im = im.convert("RGB")

        if self.transform is not None:
            im = self.transform(im)

        return im, y, r["path"]


# -------------------------
# Model
# -------------------------

def build_vit_model(num_classes: int, use_imagenet_pretrained: bool, freeze_backbone: bool):
    """
    Build a ViT-B/16 model for classification.

    TODO:
      1. Load torchvision.models.vit_b_16 with pretrained weights if requested.
      2. Replace the classification head so that the output dimension is num_classes.
    """

    # TODO: choose weights
    weights = None

    # TODO: create the ViT model
    model = None

    # TODO: replace the classification head

    # (freeze_backbone is already implemented)
    if freeze_backbone:
        for name, p in model.named_parameters():
            if not name.startswith("heads."):
                p.requires_grad = False

    return model


# -------------------------
# Train / Eval
# -------------------------

def train_one_epoch(model, loader, optimizer, loss_fn, device):
    model.train()
    total_loss, total = 0.0, 0

    for i, (x, y, _paths) in enumerate(loader):
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        logits = model(x)
        loss = loss_fn(logits, y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * y.size(0)
        total += y.size(0)

        if i % 10 == 0:
            print(f"  Batch {i:04d}/{len(loader)}  loss={loss.item():.4f}")

    return total_loss / max(1, total)


@torch.no_grad()
def eval_acc_and_dump(model, loader, device, out_csv: Path):
    model.eval()
    correct, total = 0, 0

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with out_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["path", "y_true", "y_pred"])

        for x, y, paths in loader:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            logits = model(x)
            pred = logits.argmax(dim=1)

            correct += (pred == y).sum().item()
            total += y.numel()

            pred_cpu = pred.cpu().tolist()
            y_cpu = y.cpu().tolist()
            for p, yt, yp in zip(paths, y_cpu, pred_cpu):
                w.writerow([p, yt, yp])

    return correct / max(1, total)


def save_curves(out_dir: Path, train_losses, val_accs):
    epochs = list(range(1, len(train_losses) + 1))

    fig, ax1 = plt.subplots()

    line1, = ax1.plot(
        epochs,
        train_losses,
        color="blue",
        linewidth=2,
        label="Training Loss",
    )
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Training Loss", color="blue")
    ax1.tick_params(axis="y", labelcolor="blue")

    ax2 = ax1.twinx()
    line2, = ax2.plot(
        epochs,
        val_accs,
        color="red",
        linewidth=2,
        label="Validation Accuracy",
    )
    ax2.set_ylabel("Validation Accuracy", color="red")
    ax2.tick_params(axis="y", labelcolor="red")

    plt.title("Training Loss and Validation Accuracy")

    lines = [line1, line2]
    labels = [l.get_label() for l in lines]
    ax1.legend(lines, labels, loc="best")

    fig.tight_layout()
    fig.savefig(out_dir / "training_curves.png", dpi=150)
    plt.close(fig)


# -------------------------
# Main
# -------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", type=str, required=True, help="Path to split.json")

    ap.add_argument("--pretrained", action="store_true", help="Use ImageNet pretrained ViT")
    ap.add_argument("--freeze_backbone", action="store_true", help="Freeze ViT backbone, train head only")

    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--batch_size", type=int, default=16)
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--num_workers", type=int, default=4)

    ap.add_argument("--save_best", action="store_true")
    ap.add_argument("--tag", type=str, default="", help="Extra tag for output folder name")
    ap.add_argument("--out_root", type=str, default="runs/part3")

    args = ap.parse_args()

    meta = json.loads(Path(args.split).read_text(encoding="utf-8"))
    root = Path(meta["root"])
    num_classes = int(meta["num_classes"])
    splits = meta["splits"]
    label_map = meta["label_map"]

    tag = args.tag if args.tag else "vit"
    if args.pretrained:
        tag += "_imagenet"
    if args.freeze_backbone:
        tag += "_freeze"

    out_dir = Path(args.out_root) / tag
    out_dir.mkdir(parents=True, exist_ok=True)

    (out_dir / "split_used.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    (out_dir / "label_map.json").write_text(json.dumps(label_map, indent=2), encoding="utf-8")

    train_tf = transforms.Compose([
        transforms.Resize((args.img_size, args.img_size)),
        transforms.ColorJitter(
            brightness=0.4,
            contrast=0.4,
            saturation=0.3,
            hue=0.02,
        ),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        transforms.Normalize(
            [0.485, 0.456, 0.406],
            [0.229, 0.224, 0.225],
        ),
    ])

    test_tf = transforms.Compose([
        transforms.Resize((args.img_size, args.img_size)),
        transforms.ToTensor(),
        transforms.Normalize(
            [0.485, 0.456, 0.406],
            [0.229, 0.224, 0.225],
        ),
    ])

    train_ds = SplitDataset(root, splits["train"], transform=train_tf)
    val_ds = SplitDataset(root, splits["val"], transform=test_tf)
    test_ds = SplitDataset(root, splits["test"], transform=test_tf)

    pin_memory = torch.cuda.is_available()

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = build_vit_model(
        num_classes=num_classes,
        use_imagenet_pretrained=args.pretrained,
        freeze_backbone=args.freeze_backbone,
    ).to(device)

    loss_fn = nn.CrossEntropyLoss()
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=args.lr, weight_decay=args.weight_decay)

    best_val = -1.0
    best_path = out_dir / "best.pt"
    last_path = out_dir / "last.pt"

    train_losses = []
    val_accs = []

    print(f"== Part 3: {tag} ==")
    print(f"Classes: {num_classes}")
    print(f"Train/Val/Test: {len(train_ds)}/{len(val_ds)}/{len(test_ds)}")
    print(f"Device: {device}")
    print(f"Out: {out_dir}")

    if device.type == "cpu":
        print("WARNING: Training ViT on CPU can be slow.")
        if not args.freeze_backbone:
            print("TIP: Use --freeze_backbone for a much faster CPU-friendly run.")

    for epoch in range(1, args.epochs + 1):
        loss = train_one_epoch(model, train_loader, optimizer, loss_fn, device)
        val_csv = out_dir / "predictions_val.csv"
        val_acc = eval_acc_and_dump(model, val_loader, device, val_csv)

        train_losses.append(loss)
        val_accs.append(val_acc)

        print(f"Epoch {epoch:02d}/{args.epochs}  loss={loss:.4f}  val_acc={val_acc*100:.2f}%")

        torch.save(
            {
                "model": model.state_dict(),
                "args": vars(args),
                "meta": meta,
            },
            last_path,
        )

        if args.save_best and val_acc > best_val:
            best_val = val_acc
            torch.save(
                {
                    "model": model.state_dict(),
                    "args": vars(args),
                    "meta": meta,
                },
                best_path,
            )

        save_curves(out_dir, train_losses, val_accs)

    if args.save_best and best_path.exists():
        ckpt = torch.load(best_path, map_location="cpu")
        model.load_state_dict(ckpt["model"])

    test_csv = out_dir / "predictions_test.csv"
    test_acc = eval_acc_and_dump(model, test_loader, device, test_csv)

    print(f"TEST accuracy: {test_acc*100:.2f}%")
    print(f"Wrote: {test_csv}")
    print(f"Saved plot: {out_dir / 'training_curves.png'}")


if __name__ == "__main__":
    main()