# cs4391

## Installation

### 1. Create Conda Environment

```bash
conda create -n cs4391 python=3.10
conda activate cs4391
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Install PyTorch (CUDA 13.0 example)

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu130
```

Make sure the CUDA version matches your system.  
Check available versions at: https://pytorch.org/get-started/locally/