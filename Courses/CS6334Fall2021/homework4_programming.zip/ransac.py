"""
CS 6334.001 Homework 4 Programming
Implement the ransac() function in this python script
"""

import os
import random
import time
import numpy as np
import matplotlib.pyplot as plt


# RANSAC algorithm to estimate the parameters (a, b) of a 2D line given input (x, y)
# y = ax + b
def ransac(x, y):

    # number of samples
    N = len(x)
    
    # number of iterations
    T = 100
    
    # threshld for fitting the model
    threshold = 1
    
    # maximum number of inliers so far
    K = 0
    
    # best estimation so far
    a_best = 0
    b_best = 0
    
    # main loop
    for i in range(T):
    
        # Step 1: sample two points from x and y

        
        # Step 2: estimate (a, b) using the two points

        
        # Step 3: find how many points in (x, y) fit the model using threshold defined above

        
        # Step 4: if the number of inliers > K, update K and record (a, b) as the best estimate so far
        
        
        print(a_best, b_best)

            
    return a_best, b_best


# main function
if __name__ == '__main__':

    # set the parameters of a 2D line
    a = 2
    b = 5
    
    # sample 2D points on the line
    # sample 20 xs
    N = 50
    x = np.random.uniform(-10, 10, N)
    print('x:', x)

    # compute y
    y = a * x + b
    print('y:', y)
    
    # perturb x and y
    sigma = 2
    x = x + sigma * np.random.randn(N) 
    y = y + sigma * np.random.randn(N) 
    print(x, y)
    
    # plot x and y
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    plt.scatter(x, y)
    plt.xlabel('x', fontsize = 20)
    plt.ylabel('y', fontsize = 20)
    plt.title('sampled data points (close this window to run)')
    plt.show()
    
    # call the ransac() function to estimate the parameters of the line
    a_predict, b_predict = ransac(x, y)
    print(a_predict, b_predict)
    
    # visualize the estimation
    xx = np.linspace(-10, 10, num=1000)
    y_predict = a_predict * xx + b_predict
    y_gt = a * xx + b
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    plt.scatter(x, y, c='b')
    plt.scatter(xx, y_predict, c='g')
    plt.scatter(xx, y_gt, c='r')
    ax.legend(['data points', 'predicted line', 'ground truth line'], fontsize=20)
    plt.xlabel('x', fontsize = 20)
    plt.ylabel('y', fontsize = 20)
    plt.xticks(fontsize=15)
    plt.yticks(fontsize=15)
    plt.show()
