"""
CS 6334.001 Homework 3 Programming
Implement using PnP methods to compute camera pose in the get_observation() function in this python script
"""

import os
import random
import time
import cv2
import numpy as np
import pybullet as p
import matplotlib.pyplot as plt
from scipy.ndimage.measurements import label as connected_components

class TableYCBEnv():

    def __init__(self):

        self._renders = True
        self._egl_render = False
        self.connected = False

        self._window_width = 640
        self._window_height = 480
        self.object_uid = None
        self._timeStep = 1. / 1000.
        self.root_dir = os.path.dirname(os.path.abspath(__file__))

        self.connect()
        self.reset()


    def connect(self):
        """
        Connect pybullet.
        """
        if self._renders:
            self.cid = p.connect(p.SHARED_MEMORY)
            if (self.cid < 0):
                self.cid = p.connect(p.GUI)

            p.resetDebugVisualizerCamera(0.6, 180.0, -41.0, [0.35, 0.58, 0.68])
            # p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)

        else:
            self.cid = p.connect(p.DIRECT)

        if self._egl_render:
            import pkgutil
            egl = pkgutil.get_loader("eglRenderer")
            if egl:
                p.loadPlugin(egl.get_filename(), "_eglRendererPlugin")

        self.connected = True


    def reset(self):

        # Set the camera
        look = [0, 0, 0]
        distance = 1.0
        pitch = -60
        yaw = 30
        roll = 0.
        fov = 45
        aspect = float(self._window_width) / self._window_height
        self.near = 0.1
        self.far = 10
        self._view_matrix = p.computeViewMatrixFromYawPitchRoll(look, distance, yaw, pitch, roll, 2)
        self._proj_matrix = p.computeProjectionMatrixFOV(fov, aspect, self.near, self.far)
        self._light_position = np.array([1.0, 0, -2.5])

        p.resetSimulation()
        p.setTimeStep(self._timeStep)
        p.setPhysicsEngineParameter(enableConeFriction=0)

        p.setGravity(0, 0, -9.81)
        p.stepSimulation()

        # Set table and plane
        plane_file = os.path.join(self.root_dir, 'data/floor/model_normalized.urdf') # _white
        table_file = os.path.join(self.root_dir, 'data/table/models/model_normalized.urdf')

        self.obj_path = [plane_file, table_file]
        self.plane_id = p.loadURDF(plane_file, [0, 0, 0])
        self.table_pos = np.array([0, 0, 0])
        self.table_id = p.loadURDF(table_file, self.table_pos[0], self.table_pos[1], self.table_pos[2],
                             0.707, 0., 0., 0.707)


    def _add_mesh(self, obj_file, trans, quat, scale=1):
        """
        Add a mesh with URDF file.
        """
        bid = p.loadURDF(obj_file, trans, quat, globalScaling=scale, flags=p.URDF_ENABLE_CACHED_GRAPHICS_SHAPES)
        return bid


    def place_objects(self, name):
        """
        Randomize positions of an object
        """

        # set the 3D translation [tx, ty, tz]        
        tx = 0
        ty = 0
        tz = 0.26

        # set euler angles: pitch, yaw, roll
        # then convert pitch, yaw, roll to quaternion using function p.getQuaternionFromEuler()
        pitch = 0
        yaw = 0
        roll = 0
        quaternion = p.getQuaternionFromEuler([pitch, yaw, roll])
        
        # put the mug using the 3D translation and the 3D rotation
        urdf = os.path.join(self.root_dir, 'data', name, 'model_normalized.urdf')
        uid = self._add_mesh(urdf, [tx, ty, tz], [quaternion[0], quaternion[1], quaternion[2], quaternion[3]])  # xyzw
        self.object_uid = uid
        p.resetBaseVelocity(uid, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))

        time.sleep(1.0)
        for _ in range(2000):
            p.stepSimulation()
            
            
    def projection_to_intrinsics(self, mat, width=640, height=480):
        intrinsic_matrix = np.eye(3)
        mat = np.array(mat).reshape([4, 4]).T
        fv = width / 2 * mat[0, 0]
        fu = height / 2 * mat[1, 1]
        u0 = width / 2
        v0 = height / 2

        intrinsic_matrix[0, 0] = fu
        intrinsic_matrix[1, 1] = fv
        intrinsic_matrix[0, 2] = u0
        intrinsic_matrix[1, 2] = v0
        return intrinsic_matrix	            


    def get_observation(self):
        """
        Get observation
        """

        _, _, rgba, depth, mask = p.getCameraImage(width=self._window_width,
                                                   height=self._window_height,
                                                   viewMatrix=self._view_matrix,
                                                   projectionMatrix=self._proj_matrix,
                                                   lightDirection=[0.0, 1.0, 2.0],                                                   
                                                   lightColor=[1, 1, 1],
                                                   lightDistance=1.0,
                                                   shadow=1,                                                   
                                                   lightAmbientCoeff=0.3,
                                                   lightDiffuseCoeff=0.6,
                                                   lightSpecularCoeff=0.2,
                                                   renderer=p.ER_TINY_RENDERER,
                                                   physicsClientId=self.cid)
                                                   
        # convert the images to numpy array and reshape
        rgba = np.array(rgba).reshape(self._window_height, self._window_width, 4)                                            
        detph = np.array(depth).reshape(self._window_height, self._window_width)
        mask = np.array(mask).reshape(self._window_height, self._window_width)
                                                   
        # print image information
        print('The rendered image is with shape', rgba.shape)                                                   
        print('The rendered depth is with shape', depth.shape)        
        print('The rendered segmentation mask is with shape', mask.shape)
        
        """#################################
        # Harris corner detection
        "#################################"""        
        
        # convert the mask of the plate into a binary image
        binary = np.array(mask == 2).astype(np.float32)
        
        # run Harris corner detector on the binary mask
        dst = cv2.cornerHarris(binary, 4, 3, 0.04)
        
        # only keep locations with responses larger than a threshold
        dst[dst > 0.2 * dst.max()] = 1
        
        # since there are multiple locations detected around a corner, we find connected components
        components, num_components = connected_components(dst == 1)
        print('number of connect components', num_components)
        
        # find the four corners of the plate
        corners = np.zeros((num_components, 2), dtype=np.float32)
        for i in range(num_components):
            index = np.where(components == i + 1)
            corners[i, 0] = np.mean(index[1])
            corners[i, 1] = np.mean(index[0])
        
        print('finish Harris corner detection, we find four corners')
        print(corners)
        
        """#################################
        # visualization
        "#################################"""  
        
        fig = plt.figure()
        
        # show RGB image
        ax = fig.add_subplot(2, 2, 1)
        plt.imshow(rgba[:, :, :3])        
        ax.set_title('RGB image')
        
        # show depth image
        ax = fig.add_subplot(2, 2, 2)
        plt.imshow(depth)
        ax.set_title('depth image')
        
        # show segmentation mask
        ax = fig.add_subplot(2, 2, 3)
        plt.imshow(mask)
        ax.set_title('segmentation mask')
        
        # show detected corners
        ax = fig.add_subplot(2, 2, 4)
        plt.imshow(rgba[:, :, :3])
        plt.scatter(corners[:, 0], corners[:, 1])
        ax.set_title('detected corners')
        plt.show()
        
        """#################################
        # Programming homework 3
        "#################################"""          
        
        # Programming homework 3: use PnP methods from opencv to compute the camera pose
        # so far, we have found the four corners on the image
        # the 3D locations of the four corners are (-0.05, -0.05, 0), (0.05, -0.05, 0), (0.05, 0.05, 0), (-0.05, 0.05, 0)
        # i.e., we define the world origin in the center of the plate, and the z plane is the plate plane

        # intrinsic matrix of the camera        
        intrinsic_matrix = self.projection_to_intrinsics(self._proj_matrix, self._window_width, self._window_height)        
        
        # Step 1, figure out an assignment of the 3D locations to the detected corners on the image
        # corners is with shape (4, 2)
        # The output of step 1 should be a numpy array with shape (4, 3), let's say x3d
        # Note, there can be multiple possible assignments, find one of them
        
        print('3D locations')
        # dummy: replace with your solution
        x3d = np.zeros((4, 3), dtype=np.float32)
        print(x3d)

        # Step 2: solve the pnp problem using opencv
        # Refer to this link for the cv2.solvePnP https://www.pythonpool.com/opencv-solvepnp/
        # The output of step 2 should be a rotation matrix R (3x3) and a translation vector tvec (3x1) of the camera pose
        # useful functions: cv2.solvePnP, cv2.Rodrigues

        print('3D rotation')
        # dummy: replace with your solution
        R = np.zeros((3, 3), dtype=np.float32)
        print(R, R.shape)
        
        print('3D translation')
        # dummy: replace with your solution
        tvec = np.zeros((3, 1), dtype=np.float32)
        print(tvec, tvec.shape)
        
        # Step 3: project the 3D points x3d using the estimated camera pose R, tvec (extrinsics) and the camera intrinsics to verify the solution
        # the output of step 3 should be a numpy array with shape (4, 2), let's say x2d
        
        print('projected 2D locations according to the estimated camera pose')
        # dummy: replace with your solution
        x2d = np.zeros((4, 2), dtype=np.float32)
        print(x2d, x2d.shape)
      
        

# main function
if __name__ == '__main__':

    # create the table environment
    env = TableYCBEnv()
    
    # randomly place the plate to the table
    name = 'square'
    env.place_objects(name)
       
    # render images
    env.get_observation()
