"""
CS 6334.001 Homework 1 Programming
Implement the randomly_place_objects() function in this python script
"""

import os
import random
import time
import numpy as np
import pybullet as p

class TableYCBEnv():

    def __init__(self):

        self._renders = True
        self._egl_render = False
        self.connected = False

        self._window_width = 640
        self._window_height = 480
        self.object_uid = None
        self._timeStep = 1. / 1000.
        self.root_dir = os.path.dirname(os.path.abspath(__file__))

        self.connect()
        self.reset()


    def connect(self):
        """
        Connect pybullet.
        """
        if self._renders:
            self.cid = p.connect(p.SHARED_MEMORY)
            if (self.cid < 0):
                self.cid = p.connect(p.GUI)

            p.resetDebugVisualizerCamera(0.6, 180.0, -41.0, [0.35, 0.58, 0.68])
            # p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)

        else:
            self.cid = p.connect(p.DIRECT)

        if self._egl_render:
            import pkgutil
            egl = pkgutil.get_loader("eglRenderer")
            if egl:
                p.loadPlugin(egl.get_filename(), "_eglRendererPlugin")

        self.connected = True


    def reset(self):

        # Set the camera  .
        look = [0.1, 0.2, 0]
        distance = 2.5
        pitch = -56
        yaw = 245
        roll = 0.
        fov = 20.
        aspect = float(self._window_width) / self._window_height
        self.near = 0.1
        self.far = 10
        self._view_matrix = p.computeViewMatrixFromYawPitchRoll(look, distance, yaw, pitch, roll, 2)
        self._proj_matrix = p.computeProjectionMatrixFOV(fov, aspect, self.near, self.far)
        self._light_position = np.array([-1.0, 0, 2.5])

        p.resetSimulation()
        p.setTimeStep(self._timeStep)
        p.setPhysicsEngineParameter(enableConeFriction=0)

        p.setGravity(0, 0, -9.81)
        p.stepSimulation()

        # Set table and plane
        plane_file = os.path.join(self.root_dir, 'data/floor/model_normalized.urdf') # _white
        table_file = os.path.join(self.root_dir, 'data/table/models/model_normalized.urdf')

        self.obj_path = [plane_file, table_file]
        self.plane_id = p.loadURDF(plane_file, [0, 0, 0])
        self.table_pos = np.array([0, 0, 0])
        self.table_id = p.loadURDF(table_file, self.table_pos[0], self.table_pos[1], self.table_pos[2],
                             0.707, 0., 0., 0.707)


    def _add_mesh(self, obj_file, trans, quat, scale=1):
        """
        Add a mesh with URDF file.
        """
        bid = p.loadURDF(obj_file, trans, quat, globalScaling=scale, flags=p.URDF_ENABLE_CACHED_GRAPHICS_SHAPES)
        return bid


    def randomly_place_objects(self, name):
        """
        Homework 1
        Randomize positions of an object
        """

        # Todo: sample a 3D translation of the mug, make sure when the mug drops, it lands one the table
        # you can use function np.random.uniform(a, b) to generate a random number between a and b
        # the 3D translation is [tx, ty, tz]
        


        # Todo: sample a 3D rotation
        # first sample euler angles: pitch, yaw, roll
        # then convert pitch, yaw, roll to quaternion using function p.getQuaternionFromEuler()
        
        	
        
        # put the mug using the 3D translation and the 3D rotation
        urdf = os.path.join(self.root_dir, 'data', name, 'model_normalized.urdf')
        uid = self._add_mesh(urdf, [tx, ty, tz], [quaternion[0], quaternion[1], quaternion[2], quaternion[3]])  # xyzw
        self.object_uid = uid
        p.resetBaseVelocity(uid, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))

        time.sleep(3.0)
        for _ in range(2000):
            p.stepSimulation()


    def apply_force(self, target_pos, alpha=500):
        """
        Apply force to the object
        """

        pos, orn = p.getBasePositionAndOrientation(self.object_uid)

        force = alpha * (np.array(target_pos) - np.array(pos))
        p.applyExternalForce(objectUniqueId=self.object_uid, linkIndex=-1,
                         forceObj=force, posObj=pos, flags=p.WORLD_FRAME)

        # run simulation
        time.sleep(0.2)
        for _ in range(2000):
            p.stepSimulation()


    def get_observation(self, pose=None, vis=False, acc=True ):
        """
        Get observation
        """

        _, _, rgba, depth, mask = p.getCameraImage(width=self._window_width,
                                                   height=self._window_height,
                                                   viewMatrix=self._view_matrix,
                                                   projectionMatrix=self._proj_matrix,
                                                   physicsClientId=self.cid,
                                                   renderer=p.ER_BULLET_HARDWARE_OPENGL)

# main function
if __name__ == '__main__':

    # create the table environment
    env = TableYCBEnv()
    
    # randomly place the mug to the table
    name = '025_mug'
    env.randomly_place_objects(name)

    while 1:
        # apply a random force to the mug
        target_pos = np.random.uniform(-1.0, 1.0, 3)
        env.apply_force(target_pos)
        
        # render images
        env.get_observation()
