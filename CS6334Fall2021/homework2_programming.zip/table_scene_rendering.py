"""
CS 6334.001 Homework 2 Programming
Implement backprojection of pixels in the get_observation() function in this python script
"""

import os
import random
import time
import numpy as np
import pybullet as p
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

class TableYCBEnv():

    def __init__(self):

        self._renders = True
        self._egl_render = False
        self.connected = False

        self._window_width = 640
        self._window_height = 480
        self.object_uid = None
        self._timeStep = 1. / 1000.
        self.root_dir = os.path.dirname(os.path.abspath(__file__))

        self.connect()
        self.reset()


    def connect(self):
        """
        Connect pybullet.
        """
        if self._renders:
            self.cid = p.connect(p.SHARED_MEMORY)
            if (self.cid < 0):
                self.cid = p.connect(p.GUI)

            p.resetDebugVisualizerCamera(0.6, 180.0, -41.0, [0.35, 0.58, 0.68])
            # p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)

        else:
            self.cid = p.connect(p.DIRECT)

        if self._egl_render:
            import pkgutil
            egl = pkgutil.get_loader("eglRenderer")
            if egl:
                p.loadPlugin(egl.get_filename(), "_eglRendererPlugin")

        self.connected = True


    def reset(self):

        # Set the camera
        look = [0, 0, 0]
        distance = 1.0
        pitch = -60
        yaw = 0
        roll = 0.
        fov = 45
        aspect = float(self._window_width) / self._window_height
        self.near = 0.1
        self.far = 10
        self._view_matrix = p.computeViewMatrixFromYawPitchRoll(look, distance, yaw, pitch, roll, 2)
        self._proj_matrix = p.computeProjectionMatrixFOV(fov, aspect, self.near, self.far)
        self._light_position = np.array([1.0, 0, -2.5])

        p.resetSimulation()
        p.setTimeStep(self._timeStep)
        p.setPhysicsEngineParameter(enableConeFriction=0)

        p.setGravity(0, 0, -9.81)
        p.stepSimulation()

        # Set table and plane
        plane_file = os.path.join(self.root_dir, 'data/floor/model_normalized.urdf') # _white
        table_file = os.path.join(self.root_dir, 'data/table/models/model_normalized.urdf')

        self.obj_path = [plane_file, table_file]
        self.plane_id = p.loadURDF(plane_file, [0, 0, 0])
        self.table_pos = np.array([0, 0, 0])
        self.table_id = p.loadURDF(table_file, self.table_pos[0], self.table_pos[1], self.table_pos[2],
                             0.707, 0., 0., 0.707)


    def _add_mesh(self, obj_file, trans, quat, scale=1):
        """
        Add a mesh with URDF file.
        """
        bid = p.loadURDF(obj_file, trans, quat, globalScaling=scale, flags=p.URDF_ENABLE_CACHED_GRAPHICS_SHAPES)
        return bid


    def place_objects(self, name):
        """
        Randomize positions of an object
        """

        # set the 3D translation [tx, ty, tz]        
        tx = 0
        ty = 0
        tz = 0.26

        # set euler angles: pitch, yaw, roll
        # then convert pitch, yaw, roll to quaternion using function p.getQuaternionFromEuler()
        pitch = 0
        yaw = 0
        roll = 0
        quaternion = p.getQuaternionFromEuler([pitch, yaw, roll])
        
        # put the mug using the 3D translation and the 3D rotation
        urdf = os.path.join(self.root_dir, 'data', name, 'model_normalized.urdf')
        uid = self._add_mesh(urdf, [tx, ty, tz], [quaternion[0], quaternion[1], quaternion[2], quaternion[3]])  # xyzw
        self.object_uid = uid
        p.resetBaseVelocity(uid, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))

        time.sleep(1.0)
        for _ in range(2000):
            p.stepSimulation()
            
            
    def projection_to_intrinsics(self, mat, width=640, height=480):
        intrinsic_matrix = np.eye(3)
        mat = np.array(mat).reshape([4, 4]).T
        # focal length
        fv = width / 2 * mat[0, 0]
        fu = height / 2 * mat[1, 1]
        # principal point
        u0 = width / 2
        v0 = height / 2

        intrinsic_matrix[0, 0] = fu
        intrinsic_matrix[1, 1] = fv
        intrinsic_matrix[0, 2] = u0
        intrinsic_matrix[1, 2] = v0
        return intrinsic_matrix	            


    def get_observation(self):
        """
        Get observation
        """

        _, _, rgba, depth, mask = p.getCameraImage(width=self._window_width,
                                                   height=self._window_height,
                                                   viewMatrix=self._view_matrix,
                                                   projectionMatrix=self._proj_matrix,
                                                   lightDirection=[0.0, 1.0, 2.0],                                                   
                                                   lightColor=[1, 1, 1],
                                                   lightDistance=1.0,
                                                   shadow=1,                                                   
                                                   lightAmbientCoeff=0.3,
                                                   lightDiffuseCoeff=0.6,
                                                   lightSpecularCoeff=0.2,
                                                   renderer=p.ER_TINY_RENDERER,
                                                   physicsClientId=self.cid)
                                                   
        # print information
        print('The rendered image is with shape', rgba.shape)                                                   
        print('The rendered depth is with shape', depth.shape)        
        print('The rendered segmentation mask is with shape', mask.shape)                                                   
        
        # Programming homework 2: implement backprojection of pixels on the mug to get the point cloud of the mug in the camera frame
        # The following steps are suggested by Professor Yu Xiang. You do not need to follow these steps if you have your own idea of implementing this function
        
        # Step 1, get the camera intrinsic matrix from the projection matrix
        intrinsic_matrix = self.projection_to_intrinsics(self._proj_matrix, self._window_width, self._window_height)
        print('The camera intrinsic matrix is')
        print(intrinsic_matrix)
        
        # Step 2, use function np.linalg.inv to compute the inverse of the camera intrinsic matrix
        
        
        # Step 3, use function np.meshgrid to construct the pixel coordinates (x in slide 18 of lecture 4)
        # and then convert the pixel coordinates into homogenenous coordinates (useful functions, np.ones, np.stack)
        
        
        # Step 4, backprojection using equation d K^-1 x (d is the depth, K is the intrinsic matrix, x is the homogenenous coordinate, see slide 18 of lecture 4)
        # potentially useful functions, np.multiply, np.tile

        
        # Step 5, get the points on the mug. Note that value 2 in mask indidates pixels on the mug
        # use this mask to select points on the mug

        
        # visualization for your debugging
        fig = plt.figure()
        
        # show RGB image
        ax = fig.add_subplot(2, 2, 1)
        plt.imshow(rgba[:, :, :3])
        ax.set_title('RGB image')
        
        # show depth image
        ax = fig.add_subplot(2, 2, 2)
        plt.imshow(depth)
        ax.set_title('depth image')
        
        # show segmentation mask
        ax = fig.add_subplot(2, 2, 3)
        plt.imshow(mask)
        ax.set_title('segmentation mask')
        
        # up to now, suppose you get the points mug as pmug. Its shape should be (5280, 3)
        # then you can use the following code to visualize the points in pmug
        # You shall see the figure in the homework assignment
        ax = fig.add_subplot(2, 2, 4, projection='3d')
        ax.scatter(pmug[:, 0], pmug[:, 1], pmug[:, 2], marker='.', color='r')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title('3D ploud cloud of the mug')
                  
        plt.show()        
        

# main function
if __name__ == '__main__':

    # create the table environment
    env = TableYCBEnv()
    
    # randomly place the mug to the table
    name = '025_mug'
    env.place_objects(name)
       
    # render images
    env.get_observation()
